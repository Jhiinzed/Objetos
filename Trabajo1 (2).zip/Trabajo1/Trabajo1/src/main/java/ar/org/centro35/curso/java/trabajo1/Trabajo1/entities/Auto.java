package ar.org.centro35.curso.java.trabajo1.Trabajo1.entities;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

//@Data
//@AllArgsConstructor
@Getter
@ToString
@Setter

public class Auto {
    private String marca;
    private String modelo;
    private String color;
    private double precio;
    private Radio radio;

    public Auto(String marca, String modelo, String color, double precio, Radio radio){
        this.marca = marca;
        this.modelo = modelo;
        this.color = color;
        this.precio = precio;
        this.radio = radio;
    }

    public void setRadio(Radio radio){
        this.radio = radio;
    }
    
    public Radio getRadio(){
        return this.radio;
    }


    public Auto(String marca, String modelo, String color, double precio, String marcaR, double potencia) {
        this.marca = marca;
        this.modelo = modelo;
        this.color = color;
        this.precio = precio;
        //this.radio=new Radio(marcaR, potencia);
    }

    
}

