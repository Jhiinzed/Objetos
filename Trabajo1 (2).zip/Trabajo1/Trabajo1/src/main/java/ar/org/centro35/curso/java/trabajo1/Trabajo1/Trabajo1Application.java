package ar.org.centro35.curso.java.trabajo1.Trabajo1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Trabajo1Application {

	public static void main(String[] args) {
		SpringApplication.run(Trabajo1Application.class, args);
	}

}
