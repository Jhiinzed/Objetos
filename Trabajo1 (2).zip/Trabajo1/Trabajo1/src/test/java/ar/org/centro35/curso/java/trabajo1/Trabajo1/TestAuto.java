package ar.org.centro35.curso.java.trabajo1.Trabajo1;

import ar.org.centro35.curso.java.trabajo1.Trabajo1.entities.Auto;
import ar.org.centro35.curso.java.trabajo1.Trabajo1.entities.Radio;

public class TestAuto {
    public static void main(String[] args) {
        //Auto Clasico sin radio:
        System.out.println("--- AutoClasico ---");
        Auto AutoClasico=new Auto("qwe", "asd", "zxc", 111,null);
    
        System.out.println(AutoClasico);
        // Agregar radio al Auto Clasico:
        //Radio radio=new Radio("Radiecito", 1112);
        //AutoClasico.
        //System.out.println(AutoClasico);
        
       // System.out.println(AutoClasico);
        
    }
}
