package ar.org.centro35.curso.java.Test;

import ar.org.centro35.curso.java.trabajo1.Trabajo1.entities.Vehiculo;
import ar.org.centro35.curso.java.trabajo1.Trabajo1.entities.AutoClasico;
import ar.org.centro35.curso.java.trabajo1.Trabajo1.entities.AutoNuevo;
import ar.org.centro35.curso.java.trabajo1.Trabajo1.entities.Radio;
import ar.org.centro35.curso.java.trabajo1.Trabajo1.entities.Bondi;
public class TestAuto {
    public static void main(String[] args) {
        //Auto Clasico sin radio:

        /*System.out.println("--- AutoClasico ---");
        Vehiculo AutoClasico=new Vehiculo("Fiat", "Uno", "Gris", 12000, null, 0);
    
        System.out.println(AutoClasico);

        // Agregar radio al Auto Clasico:

        System.out.println("---- Agregar Radio al auto clasico ---");
        Radio Radiecito=new Radio("Radiecito", 1111);
        AutoClasico.setRadio(Radiecito);
        System.out.println(AutoClasico);
*/
        // AutoClasico

        System.out.println(" ---- AutoClasico ----");

        System.out.println();

        Vehiculo AutoClasico1=new AutoClasico("Ford", "Falcon", "Verde", 7500);
        System.out.println(AutoClasico1);

        System.out.println();

        System.out.println(" --- Agregar Radio al AutoClasico ---");

        Radio Radiecito=new Radio("Radiecito", 1111);
        AutoClasico1.setRadio(Radiecito);
        System.out.println(AutoClasico1);

        System.out.println();

        // AutoNuevo
        System.out.println(" --- AutoNuevo ---");

        Vehiculo AutoNuevo=new AutoNuevo("Fiat", "Cronos", "Blanco", 25000, "Radiecito2.0", 1452);
        System.out.println(AutoNuevo);
        System.out.println();

        System.out.println("--- Cambiar Radio al AutoNuevo ---");

        Radio Radiecito3=new Radio("Radiecito3", 111115);
        AutoNuevo.setRadio(Radiecito3);
        System.out.println(AutoNuevo);

        System.out.println();

        System.out.println(" --- Bondi ---");

        Vehiculo Bondi=new Bondi("Mercedes", "98", "Amarillo/Verde", 45000);
        System.out.println(Bondi);

        System.out.println("---Agregar Radio al bondi---");
        Radio Radiecito4=new Radio("Radiecito4", 14568);
        Bondi.setRadio(Radiecito4);
        System.out.println(Bondi);
    }
}
