package ar.org.centro35.curso.java.trabajo1.Trabajo1.entities;

import javax.swing.JOptionPane;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Data
//@AllArgsConstructor
@Getter
@Setter
@ToString

public class Radio {
private String marcaR;
private double potencia;

public Radio(String marcaR, double potencia){
    this.marcaR = marcaR;
    this.potencia = potencia;
}



}