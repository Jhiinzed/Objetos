package ar.org.centro35.curso.java.trabajo1.Trabajo1.entities;

import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
//@AllArgsConstructor

public class AutoClasico extends Vehiculo {
    /*private String marca;
    private String modelo;
    private String color;
    private double precio;*/
 
     public AutoClasico(String marca, String modelo, String color, double precio) {
         super(marca, modelo, color, precio);
        this.marca = marca;
        this.modelo = modelo;
        this.color = color;
        this.precio = precio;

     }
}
