package ar.org.centro35.curso.java.trabajo1.Trabajo1.entities;

import lombok.Getter;

@Getter

public class AutoNuevo extends Vehiculo {
    /*private String marca;
    private String modelo;
    private String color;
    private double precio;*/
    private Radio radio;

    public AutoNuevo(String marca, String modelo, String color, double precio, String marcaRadio, double potencia) {
        super(marca, modelo, color, precio, marcaRadio, potencia);
        this.marca = marca;
        this.modelo = modelo;
        this.color = color;
        this.precio = precio;
        this.radio =new Radio(marcaRadio, potencia);

    }

     public Radio getRadio(){
        return this.radio;
    }
    
    public void setRadio(Radio radio) {
        this.radio = radio;
    }
}
