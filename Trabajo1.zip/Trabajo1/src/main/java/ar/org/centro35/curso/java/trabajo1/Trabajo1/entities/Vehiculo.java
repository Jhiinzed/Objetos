package ar.org.centro35.curso.java.trabajo1.Trabajo1.entities;

import lombok.Data;
//import lombok.Getter;
//import lombok.Setter;
import lombok.ToString;
import ar.org.centro35.curso.java.trabajo1.Trabajo1.entities.Radio;

//@Getter
@ToString
//@Setter
@Data

public class Vehiculo {
    protected String marca;
    protected String modelo;
    protected String color;
    protected double precio;
    private Radio radio;

    public Vehiculo(String marca, String modelo, String color, double precio) {
        this.marca = marca;
        this.modelo = modelo;
        this.color = color;
        this.precio = precio;
        // this.radio = radio;
    }

    public Vehiculo(String marca, String modelo, String color, double precio, String marcaRadio, double potencia) {
        this.marca = marca;
        this.modelo = modelo;
        this.color = color;
        this.precio = precio;
        this.radio = new Radio(marcaRadio, potencia);
    }

    public void setRadio(Radio radio) {
        this.radio = radio;
    }

    public Radio getRadio() {
        return this.radio;
    }

}
