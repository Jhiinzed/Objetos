package ar.org.centro35.curso.java.trabajo1.Trabajo1.entities;

import lombok.Getter;

@Getter

public class AutoClasico extends Vehiculo {

    public AutoClasico(String marca, String modelo, String color, double precio) {
        super(marca, modelo, color, precio);
        this.marca = marca;
        this.modelo = modelo;
        this.color = color;
        this.precio = precio;

    }
}
