package ar.org.centro35.curso.java.claseAutobis;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ClaseAutobisApplicationTests {

	@Test
	void contextLoads() {
	}

}
