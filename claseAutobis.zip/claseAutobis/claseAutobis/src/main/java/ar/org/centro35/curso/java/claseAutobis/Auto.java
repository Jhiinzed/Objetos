package main.java.ar.org.centro35.curso.java.claseAutobis;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@AllArgsConstructor

@Data

public class Auto {
   private String marca;
   private String modelo;
   private String color;
   private int velocidad;
    
} 