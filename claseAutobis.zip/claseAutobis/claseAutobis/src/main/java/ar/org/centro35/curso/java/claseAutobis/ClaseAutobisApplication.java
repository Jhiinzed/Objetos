package ar.org.centro35.curso.java.claseAutobis;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ClaseAutobisApplication {

	public static void main(String[] args) {
		SpringApplication.run(ClaseAutobisApplication.class, args);
	}

}
