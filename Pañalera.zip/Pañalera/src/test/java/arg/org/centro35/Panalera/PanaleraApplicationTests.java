package arg.org.centro35.Panalera;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PanaleraApplicationTests {

	@Test
	void contextLoads() {
	}

}
