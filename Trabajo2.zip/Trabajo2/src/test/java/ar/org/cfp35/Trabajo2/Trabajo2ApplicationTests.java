package ar.org.cfp35.Trabajo2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Trabajo2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
